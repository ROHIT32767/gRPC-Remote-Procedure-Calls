# Master.py
cd P2; cd client; python3 master.py --query 2 --mappers 3 --reducers 2